# OldNetflix
created a static netflix clone website showing the landing page of the OG one usig HTML5 CSS3 and vanilla JS learnt alot 💪🔥
